# DevOps-app

# Jenkins Pipeline

![pipeline](https://user-images.githubusercontent.com/22007858/56476894-ecaacf80-6496-11e9-8ccc-0818e12f44ce.png)
